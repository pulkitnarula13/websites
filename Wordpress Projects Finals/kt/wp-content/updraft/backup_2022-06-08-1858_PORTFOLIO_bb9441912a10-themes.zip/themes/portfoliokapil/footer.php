
<?php ?>
</main> 
 <!-- .site-main -->
  <footer  class="site-footer" id="site-footer ">
  <div class="mainfoot" id = "12">
        <div class="content">
           <a href="http://kapilthaman.com/2021/11/29/about-me/"><button class="contactbtn">CONTACT ME</button></a>
        </div>
    </div>
  </footer>
  
</div>  
</body>     <!-- .content-area -->
<?php wp_footer(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/vanilla-tilt/1.7.2/vanilla-tilt.min.js"></script>

</html>