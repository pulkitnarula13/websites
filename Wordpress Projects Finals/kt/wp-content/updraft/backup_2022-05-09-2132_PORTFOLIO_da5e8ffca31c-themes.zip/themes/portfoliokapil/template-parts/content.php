<?php ?>

<article <?php post_class(); ?>>

<h2 class="entry-title">

 <?php the_title(); ?>

</h2>

<div class="post-content">

  <?php the_content(); ?>

  </div>
 
</article>